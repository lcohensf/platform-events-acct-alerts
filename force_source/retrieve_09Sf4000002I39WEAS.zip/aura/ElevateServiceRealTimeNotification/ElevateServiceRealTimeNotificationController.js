({
    onCometdLoaded : function(component, event, helper) {
        var cometd = new org.cometd.CometD();
        component.set('v.cometd', cometd);
        if (component.get('v.sessionId') != null)
            helper.connectCometd(component);
    },
    
    onInit : function(component, event, helper) {
        console.log('In onInit');
        
        component.set('v.cometdSubscriptions', []);
        component.set('v.notifications', []);
        
        // Disconnect CometD when leaving page
        window.addEventListener('unload', function(event) {
            helper.disconnectCometd(component);
        });
        
        // Retrieve session id
        var action = component.get('c.getSessionId');
        action.setCallback(this, function(response) {
            console.log('in sessionid callback');
            if (component.isValid() && response.getState() === 'SUCCESS') {
                console.log('component is valid');
                component.set('v.sessionId', response.getReturnValue());
                if (component.get('v.cometd') != null) {
                    console.log('about to call helper.connectCometd');
                    helper.connectCometd(component);
                }
                else {
                    console.log('v.cometd was null');
                }
            }
            else
                console.error(response);
        });
        $A.enqueueAction(action);
        
        //helper.displayToast(component, 'success', 'Ready to receive notifications.');
    },
    
    
    onClear : function(component, event, helper) {
        component.set('v.notifications', []);
    }, 
    
    onTakeAction : function(component, event, helper) {
        var aID = event.getSource().get("v.value");
        helper.displayToast(component, 'success', 'Take action on this account: ' + aID);
    }
    
    
})