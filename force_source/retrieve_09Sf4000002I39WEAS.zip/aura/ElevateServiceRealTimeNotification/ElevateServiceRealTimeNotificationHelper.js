({
    connectCometd : function(component) {
        
        var helper = this;
        
        // Configure CometD
        var cometdUrl = window.location.protocol+'//'+window.location.hostname+'/cometd/40.0/';
        var cometd = component.get('v.cometd');
        
        console.log('in helper connectCometd');
        
        cometd.configure({
            url: cometdUrl,
            requestHeaders: { Authorization: 'OAuth '+ component.get('v.sessionId')},
            appendMessageTypeToURL : false
        });
        cometd.websocketEnabled = false;
        
        // Establish CometD connection
        console.log('Connecting to CometD: '+ cometdUrl);
        cometd.handshake(function(handshakeReply) {
            if (handshakeReply.successful) {
                console.log('Connected to CometD.');
                // Subscribe to platform event
                var newSubscription = cometd.subscribe('/event/pedemo__ElevateServiceAlert__e', 
                                                       function(platformEvent) {
                                                           console.log('Platform event received: '+ JSON.stringify(platformEvent));
                                                           helper.onReceiveNotification(component, platformEvent);
                                                       }
                                                      );
                // Save subscription for later
                var subscriptions = component.get('v.cometdSubscriptions');
                subscriptions.push(newSubscription);
                component.set('v.cometdSubscriptions', subscriptions);
                console.log('end of if handshakeReply.successful');
            }
            else
                console.error('Failed to connected to CometD.');
        });
    },
    
    disconnectCometd : function(component) {
        var cometd = component.get('v.cometd');
        
        // Unsuscribe all CometD subscriptions
        cometd.batch(function() {
            var subscriptions = component.get('v.cometdSubscriptions');
            subscriptions.forEach(function (subscription) {
                cometd.unsubscribe(subscription);
            });
        });
        component.set('v.cometdSubscriptions', []);
        
        // Disconnect CometD
        cometd.disconnect();
        console.log('CometD disconnected.');
    },
    
    onReceiveNotification : function(component, platformEvent) {
        var helper = this;
        // Extract notification from platform event
        var aID = platformEvent.data.payload.pedemo__AccountID__c;
        var rID = component.get("v.recordId");
        console.log('aid = ' + aID + ' rid = ' + rID);
        if (aID != rID) {
            // ignore notifications for other Accounts
            // when topic filtering is available, subscribe on account ID to 
            // make this component more efficient
            //helper.displayToast(component, 'debug', 'ignoring notification for different account: ' + aid);
            return; 
        }
       
        var newNotification = {
            time : $A.localizationService.formatDateTime(
                platformEvent.data.payload.CreatedDate, 'HH:mm'),
            message : platformEvent.data.payload.pedemo__Reason__c, 
            AccountID__c : platformEvent.data.payload.pedemo__AccountID__c
        };
        // Save notification in history
        var notifications = component.get('v.notifications');
        notifications.unshift(newNotification);
        component.set('v.notifications', notifications);
        // Display notification in a toast if not muted
        //if (!component.get('v.isMuted'))
        helper.displayToast(component, 'info', newNotification.message);
    },
    
    displayToast : function(component, type, message) {
        var toastEvent = $A.get('e.force:showToast');
        toastEvent.setParams({
            type: type,
            message: message
        });
        toastEvent.fire();
    }
})